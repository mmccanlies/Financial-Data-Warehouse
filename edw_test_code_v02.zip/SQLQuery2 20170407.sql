SELECT * FROM dim_creditmemo
WHERE baseSubscriptionId = 9606

SELECT * FROM dim_subscription_details
WHERE baseSubscriptionId = 9606
ORDER BY subscriptionId, isCreditMemo ASC

SELECT * FROM dim_creditmemo WHERE subscriptionId = 1713

SELECT * FROM vw_custom_subscription WHERE [customFieldList-custrecord_base_subscription] = '9606'
SELECT TOP 10 * FROM vw_creditmemo WHERE tranId = 'CM6910001744'

[tranId] = '837'
[customFieldList-custrecord_base_subscription] = '1713'

internalId = '837'
WHERE Subscription = 'A-S00001713'

SELECT * FROM dim_subscription
WHERE baseSubscriptionId = 1713
ORDER BY subscriptionId, isCreditMemo ASC

SELECT * FROM vw_custom_subscription WHERE [customFieldList-custrecord_base_subscription] = '213'
[customFieldList-custrecord_base_subscription] = 'A-S00000213'

SELECT top 10 * FROM vw_creditMemo WHERE [tranId] = 'CM6910005138'
SELECT top 10 * FROM vw_creditMemo_itemList WHERE internalId = '7119268'
SELECT * FROM vw_salesOrder WHERE internalId = '7024127'
SELECT * FROM vw_salesOrder_itemList WHERE internalId = '7024127'
SELECT * FROM vw_invoice WHERE [createdFrom-internalId] = '7024127'
SELECT * FROM vw_invoice_itemList WHERE [internalId] = '7065693'


SELECT * FROM dim_salesOrder WHERE salesOrderId = 7024127
SELECT * FROM dim_invoice WHERE invoiceId = '7065693'

SELECT * FROM xrf_index WHERE baseSubscriptionId = 213

SELECT * FROM [dim_subscription] WHERE baseSubscriptionId = 213
ORDER BY xrfIndexId

SELECT * FROM [dim_creditMemo] WHERE baseSubscriptionId = 213

SELECT * FROM [fact_arr] WHERE baseSubscriptionId = 213 ORDER BY subscriptionId

-- find duplicate credit memo records
SELECT f.baseSubscriptionId, f.subscriptionId, creditMemoNo, COUNT(*) 
FROM dim_subscription s
JOIN fact_arr f ON f.subscriptionId = s.subscriptionId 
AND s.creditMemoNo IS NOT NULL 
AND s.isCreditMemo = f.isCreditMemo
GROUP BY f.baseSubscriptionId, f.subscriptionId, creditMemoNo
HAVING COUNT(*) > 2

ORDER BY 1, 2

SELECT * FROM [dim_subscription_details] WHERE baseSubscriptionId = 213
ORDER BY xrfIndexId

SELECT * FROM [vw_subscription_sequence] WHERE base = 213

SELECT * FROM [vw_subscription_list] WHERE baseSubscriptionId = 213
SELECT COUNT(*)
        FROM [vw_custom_subscription]
        JOIN [xrf_index] ON [xrf_index].[subscriptionId] = [vw_custom_subscription].[internalId]
        JOIN [vw_subscription_sequence] x ON x.sub2 = [vw_custom_subscription].[internalId]
        JOIN [vw_subscription_list] sub1 ON sub1.baseSubscriptionId = x.Base AND sub1.subscriptionId = x.sub1
        JOIN [vw_subscription_list] sub2 ON sub2.baseSubscriptionId = x.Base AND sub2.subscriptionId = x.sub2
WHERE  [vw_custom_subscription].[internalId] = '10313'




        SELECT DISTINCT
          [xrf_index].[xrfIndexId] AS 'xrfIndexId'
        , [xrf_index].[baseSubscriptionId] AS 'baseSubscriptionId'
        , [xrf_index].[subscriptionId] AS 'subscriptionId'
        , [xrf_index].[salesOrderId]  AS 'salesOrderId'
        , [xrf_index].[salesOrderItemLineId]  AS 'salesOrderLineId'
        , [xrf_index].[invoiceId]  AS 'invoiceId'
        , [xrf_index].[invItemLineId]  AS 'invoiceLineId'

        FROM [vw_custom_subscription]
        JOIN [xrf_index] ON [xrf_index].[subscriptionId] = [vw_custom_subscription].[internalId]
        JOIN [vw_subscription_sequence] x ON x.sub2 = [vw_custom_subscription].[internalId]
        JOIN [vw_subscription_list] sub1 ON sub1.baseSubscriptionId = x.Base AND sub1.subscriptionId = x.sub1
        JOIN [vw_subscription_list] sub2 ON sub2.baseSubscriptionId = x.Base AND sub2.subscriptionId = x.sub2
        WHERE [xrf_index].[isBase] != 1
AND [xrf_index].[baseSubscriptionId] = 9606

UNION ALL
       SELECT DISTINCT
          [xrf_index].[xrfIndexId]
        , [xrf_index].[baseSubscriptionId] AS 'baseSubscriptionId' 
        , [xrf_index].[subscriptionId] AS 'subscriptionId'
        , [xrf_index].[salesOrderId]  AS 'salesOrderId'
        , [xrf_index].[salesOrderItemLineId]  AS 'salesOrderLine'
        , [xrf_index].[invoiceId]  AS 'invoiceId'
        , [xrf_index].[invItemLineId]  AS 'invoiceLine'
        FROM [vw_custom_subscription]
        JOIN [xrf_index] ON [xrf_index].[subscriptionId] = [vw_custom_subscription].[internalId]
         AND [xrf_index].[isBase] = 1
AND [xrf_index].[baseSubscriptionId] = 9606

UNION ALL
       SELECT DISTINCT
          [fact_arr].[xrfIndexId] AS 'xrfIndexId'
        , [fact_arr].[baseSubscriptionId] AS 'baseSubscriptionId'
        , [fact_arr].[subscriptionId] AS 'subscriptionId'
        , [fact_arr].[salesOrderId] AS 'salesOrderId'
        , [fact_arr].[salesOrderItemLineId] AS 'salesOrderItemLineId'
        , [fact_arr].[invoiceId] AS 'invoiceId'
        , [fact_arr].[invItemLineId] AS 'invItemLineId'
        FROM [dim_creditmemo] 
        JOIN [fact_arr] ON [fact_arr].[subscriptionId] = [dim_creditmemo].[subscriptionId]
        WHERE [fact_arr].[isCreditMemo] = 0
AND [fact_arr].[baseSubscriptionId] = 9606

SELECT * FROM xrf_index WHERE [baseSubscriptionId] = 9606

        SELECT DISTINCT
          [xrf_index].[xrfIndexId] AS 'xrfIndexId'
        , [xrf_index].[baseSubscriptionId] AS 'baseSubscriptionId'
        , [xrf_index].[subscriptionId] AS 'subscriptionId'
        , [xrf_index].[isBase]
        , [xrf_index].[salesOrderId]  AS 'salesOrderId'
        , [xrf_index].[salesOrderItemLineId]  AS 'salesOrderLineId'
        , [xrf_index].[invoiceId]  AS 'invoiceId'
        , [xrf_index].[invItemLineId]  AS 'invoiceLineId'

        FROM [vw_custom_subscription]
        JOIN [xrf_index] ON [xrf_index].[subscriptionId] = [vw_custom_subscription].[internalId]
        JOIN [vw_subscription_sequence] x ON x.sub2 = [vw_custom_subscription].[internalId]
AND [xrf_index].[baseSubscriptionId] = 9606

        JOIN [vw_subscription_list] sub1 ON sub1.baseSubscriptionId = x.Base AND sub1.subscriptionId = x.sub1
        JOIN [vw_subscription_list] sub2 ON sub2.baseSubscriptionId = x.Base AND sub2.subscriptionId = x.sub2
        WHERE [xrf_index].[isBase] != 1

SELECT * 
FROM [vw_subscription_list]
WHERE baseSubscriptionId = 9606


SELECT * 
FROM [vw_subscription_sequence] x
WHERE [base] = 9606

SELECT * FROM [dim_subscription] WHERE baseSubscriptionId = 837


SELECT DISTINCT s.baseSubscriptionId, COUNT(s.subscriptionId) --, COUNT(*)
FROM dim_subscription s
JOIN 
     (
        SELECT DISTINCT baseSubscriptionId 
        FROM [dim_subscription] 
        WHERE CreditMemoNo IS NOT NULL
        AND isNew = 1
        AND isCreditMemo = 0
     ) x
     ON s.baseSubscriptionId = x.baseSubscriptionId
GROUP BY s.baseSubscriptionId
HAVING COUNT(s.subscriptionId) > 2
ORDER BY s.baseSubscriptionId

-- all records of same base subscription where a credit memo exists
SELECT * 
FROM [dim_subscription] 
JOIN (
        SELECT DISTINCT s2.baseSubscriptionId, COUNT(s2.subscriptionId) AS Cnt
        FROM [dim_subscription] s1
        JOIN [dim_subscription] s2  ON s1.baseSubscriptionId = s2.baseSubscriptionId
        WHERE s1.CreditMemoNo IS NOT NULL
        AND s1.isNew = 1
        AND s1.isCreditMemo = 0
        GROUP BY s2.baseSubscriptionId
        HAVING COUNT(s2.subscriptionId) > 2
        --ORDER BY s2.baseSubscriptionId
     ) x ON [dim_subscription].baseSubscriptionId = x.baseSubscriptionId
ORDER BY [dim_subscription].baseSubscriptionId, [dim_subscription].subscriptionId

SELECT * FROM (
SELECT * FROM [dim_subscription_details] 
WHERE CreditMemoNo IS NOT NULL
AND isCreditMemo = 0
AND prefix = 'New'
UNION
SELECT * FROM [dim_subscription_details] 
WHERE CreditMemoNo IS NOT NULL
AND isCreditMemo = 1
AND prefix != 'New'
) x
ORDER BY baseSubscriptionId




      SELECT DISTINCT 
          CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_base_subscription]) AS 'baseSubscriptionId'
        , CONVERT(int,[vw_custom_subscription].[internalId]) AS 'subscriptionId'
        , TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric)  AS 'subsLine'
        , [vw_salesorder_itemlist].[line] AS 'salesOrderToSubsLine'
        , [vw_creditmemo].[internalId] AS 'creditMemoId'
        , [vw_custom_subscription].[customFieldList-custrecord_credit_memo] AS 'creditMemoNo' 
        , CAST([customFieldList-custrecord_base_subscription_flag] AS int) AS 'isBase'
        , ISNULL(CAST([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction] AS int),-1)  AS 'salesOrderId'
        , ISNULL(TRY_CAST(ISNULL([vw_invoice].[internalId],[xrf_legacy_invoice_salesorder].[invoiceInternalId]) AS int),-1) AS 'invoiceId'
        , TRY_CAST(ISNULL([vw_salesorder_itemlist].[customFieldList-custcol_line_id],1) AS numeric) AS 'salesOrderItemLineId'
        , TRY_CAST(ISNULL([vw_invoice_itemlist].[customFieldList-custcol_line_id],1) AS numeric) AS 'invItemLineId' 

        , ISNULL(CAST([vw_custom_sales_out].[internalId] AS int),-1) AS 'salesOutId'
        , ISNULL(TRY_CAST([vw_custom_sales_out].[customFieldList-custrecord_sales_out_original_line_num] AS int),1) AS 'salesOutLineId'
        , ISNULL(CAST([vw_salesorder_itemlist].[class-internalId] AS int),-1) AS 'classId'
        , ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_item]),-1) AS 'itemId'
        , ISNULL(CAST([vw_salesorder_itemlist].[item-internalId] AS int),-1) AS 'salesOrderItemId'
        , ISNULL(CAST([vw_invoice_itemlist].[item-internalId] AS int),-1) AS 'invItemId'

        , ISNULL([vw_salesOrder].[customFieldList-custbody_om_salesperson],-1) AS 'salesOrgId'
        , ISNULL(CAST([vw_salesorder].[customFieldList-custbody_bill_customer] AS int),-1) AS 'billCustomerId'
        , ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_end_customer]),-1) AS 'endCustomerId'
        , -1 AS 'resellerId'
        --INTO xrf_index

        SELECT * FROM [xrf_legacy_invoice_salesorder]

SELECT TOP 10 *
FROM [fdw_raw].[fdw_raw].[ns_custom_subscription]


    SELECT [vw_invoice].[createdFrom-internalId] , [vw_salesorder_itemList].[internalId], [vw_salesorder_itemlist].[line], TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric), ISNULL([vw_invoice].[internalId],[xrf_legacy_invoice_salesorder].[invoiceInternalId]),  [vw_custom_subscription].*
        FROM [vw_custom_subscription] 
        JOIN [vw_nonInventorySaleItem] ON [vw_nonInventorySaleItem].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_item] 
        LEFT OUTER JOIN [vw_creditmemo] ON [vw_custom_subscription].[customFieldList-custrecord_credit_memo] = [vw_creditmemo].[tranId]
        LEFT OUTER JOIN [vw_salesorder] ON [vw_salesorder].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
        LEFT OUTER JOIN [vw_salesorder_itemlist] ON [vw_salesorder_itemlist].[internalId] = [vw_salesorder].[internalId]
                    AND TRY_CAST(ISNULL([vw_salesorder_itemlist].[line],1) AS numeric) = TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric)  -- Added
        LEFT OUTER JOIN [vw_invoice] ON [vw_invoice].[createdFrom-internalId] = [vw_salesorder].[internalId]
        LEFT OUTER JOIN [xrf_legacy_invoice_salesorder] ON [xrf_legacy_invoice_salesorder].[salesOrderInternalId] = [vw_salesorder].[internalId] 
WHERE [vw_custom_subscription].internalId = '837'
        JOIN [vw_invoice_itemlist] ON [vw_invoice_itemlist].[internalId] = ISNULL([vw_invoice].[internalId],[xrf_legacy_invoice_salesorder].[invoiceInternalId])  
                    AND CAST([vw_invoice_itemlist].[item-internalId] AS int) = CAST([vw_salesorder_itemlist].[item-internalId] AS int)
                    AND TRY_CAST([vw_invoice_itemlist].[customFieldList-custcol_line_id] AS numeric) = TRY_CAST([vw_salesorder_itemlist].[customFieldList-custcol_line_id] AS numeric)   -- Added
        LEFT OUTER JOIN [vw_custom_sales_out] ON [vw_custom_sales_out].[customFieldList-custrecord_original_sales_order] =  [vw_salesorder_itemList].[internalId] 
                    AND [vw_custom_sales_out].[customFieldList-custrecord_sales_out_original_line_num] = [vw_salesorder_itemlist].[customFieldList-custcol_line_id]  -- Added
                    AND [vw_custom_sales_out].[customFieldList-custrecord_sales_out_amount] >= 0
        LEFT OUTER JOIN [vw_customer] bill_cust ON ISNULL(CONVERT(int,bill_cust.[internalId]),-1) = ISNULL(CONVERT(int,[vw_salesorder].[customFieldList-custbody_bill_customer]),-1) 
        LEFT OUTER JOIN [vw_customer] end_cust  ON ISNULL(CONVERT(int, end_cust.[internalId]),-1) = ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_end_customer]),-1)
        ORDER BY CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_base_subscription])
               , CONVERT(int,[vw_custom_subscription].[internalId])
        ;

 
SELECT * FROM vw_custom_subscription WHERE internalId = '837'

SELECT COUNT(*) FROM vw_custom_subscription WHERE [customFieldList-custrecord_subscription_transaction] IS NULL

SELECT COUNT(*) FROM vw_custom_subscription WHERE [customFieldList-custrecord_subscription_transaction_line] IS NULL

SELECT COUNT(*) FROM vw_custom_subscription WHERE [customFieldList-custrecord_subscription_transaction_no] IS NULL

SELECT 
  [customFieldList-custrecord_base_subscription] 
, [internalId]
, [customRecordId]
, [customFieldList-custrecord_subscription_transaction_no]
, [customFieldList-custrecord_subscription_transaction]
, [customFieldList-custrecord_subscription_transaction_line]
FROM vw_custom_subscription WHERE [customFieldList-custrecord_subscription_transaction_line] IS NULL
ORDER BY CONVERT(int,[customFieldList-custrecord_base_subscription]), CONVERT(int,[internalId])

SELECT COUNT(*) FROM vw_invoice WHERE [createdFrom-internalId] IS NULL
SELECT COUNT(*) FROM vw_invoice WHERE [customFieldList-custbody_legacy_sales_order] IS NULL
SELECT * FROM vw_invoice WHERE [createdFrom-internalId] IS NULL AND [customFieldList-custbody_legacy_sales_order] IS NULL

SELECT COUNT(*) FROM vw_salesOrder WHERE [customFieldList-custbody_legacy_sales_order] IS  NULL
SELECT COUNT(*) FROM vw_salesOrder WHERE [customFieldList-custbody_transaction_case] IS NOT NULL

SELECT 
  inv.tranId, inv.internalId, inv.[createdFrom-internalId]
, so.tranID, so.internalId, so.[customFieldList-custbody_legacy_sales_order]
, sub.[customFieldList-custrecord_subscription_transaction_no]
, sub.[customFieldList-custrecord_subscription_transaction]
, sub.[customFieldList-custrecord_subscription_transaction_line]
FROM vw_salesOrder so
JOIN vw_invoice inv ON inv.otherRefNum = so.otherRefNum
JOIN vw_custom_subscription sub ON sub.[customFieldList-custrecord_subscription_transaction] = so.internalId
AND sub.[internalId] = '837'

UPDATE [fdw_raw].[fdw_raw].[ns_invoice] SET
[createdFrom-internalId] = [salesOrderInternalId]
FROM [fdw_raw].[fdw_raw].[ns_invoice] 
JOIN [xrf_legacy_invoice_salesorder] ON [xrf_legacy_invoice_salesorder].[invoiceInternalId] = [ns_invoice].[internalId]
WHERE [createdFrom-internalId] IS NULL
GO

SELECT 
  sol.internalId
, inv.internalId
, sub.[customFieldList-custrecord_subscription_transaction_no]
, sub.[customFieldList-custrecord_subscription_transaction]
, sub.[customFieldList-custrecord_subscription_transaction_line]
FROM vw_salesOrder_itemList sol
JOIN vw_custom_subscription sub ON sub.[customFieldList-custrecord_subscription_transaction] = sol.internalId 
AND TRY_CAST(ISNULL(sol.[line],1) AS numeric) = TRY_CAST(ISNULL(sub.[customFieldList-custrecord_subscription_transaction_line],1) AS numeric) 
JOIN vw_invoice inv ON inv.[createdFrom-internalId] = sol.[internalId]
AND sub.[internalId] = '837'

JOIN vw_invoice_itemList invl ON inv.otherRefNum = so.otherRefNum

[vw_salesorder].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
TRY_CAST(ISNULL([vw_salesorder_itemlist].[line],1) AS numeric) = TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric)  -- Added


SELECT internalId
, line
, [customFieldList-custcol_line_id] 
, [item-internalId]
FROM vw_salesOrder_itemList 
WHERE internalId = '639887'

SELECT COUNT(*) FROM vw_salesOrder_itemList 
WHERE [line] != CONVERT(bigint,CONVERT(numeric,[customFieldList-custcol_line_id]))

SELECT 
internalId
, [customFieldList-custcol_line_id]
, orderline
, [item-internalId]
FROM vw_invoice_itemList WHERE internalId = '751519'

SELECT * FROM vw_invoice_itemList WHERE internalId = '751519'

SELECT * FROM vw_salesOrder 
WHERE internalId = '639887'
[line]
[customFieldList-custcol_line_id]
SELECT * FROM vw_salesOrder WHERE otherRefNum = 'PA041071'

WHERE [tranId] = 'SO1201607'
internalId =  '639887'

SELECT * FROM vw_invoice WHERE otherRefNum = 'PA041071'

WHERE [tranId] = 'INVZ00000941'
internalId = '751519'

SELECT * FROM [xrf_legacy_invoice_salesorder] WHERE salesOrderNo = 'SO1201607'

invoiceNo = 'INV00000941'

[invoiceInternalId] =  '639887'
[salesOrderInternalId] =  '639887'


SELECT * FROM vw_invoice WHERE [createdFrom-internalId] = '639887'



SELECT * FROM vw_custom_subscription WHERE [customFieldList-custrecord_base_subscription] = '837'
SELECT * FROM xrf_index WHERE baseSubscriptionId = 837

SELECT * FROM arr_walk_report_4
WHERE baseSubscriptionId = 9606
ORDER BY subscriptionId, startDate

     INSERT INTO [xrf_legacy_invoice_salesorder] 
      ( baseSubscriptionId, subscriptionId, salesOrderInternalId, salesOrderNo, invoiceInternalId, invoiceNo )
      SELECT DISTINCT 
        [vw_custom_subscription].[customFieldList-custrecord_base_subscription] AS 'baseSubscriptionId'
      , [vw_custom_subscription].[internalId] AS 'subscriptionId'
      , [vw_salesOrder].[internalId] AS 'salesOrderId'
      , [vw_salesOrder].[tranId] AS 'salesOrderNo'
      , [vw_invoice].[internalId] AS 'invoiceId'
      , [vw_salesOrder].[customFieldList-custbody_legacy_sales_order] AS 'salesOrderInvNo'
      FROM [vw_custom_subscription] 
      LEFT OUTER JOIN [vw_salesorder] ON [vw_salesorder].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
      JOIN [vw_invoice] ON REPLACE([vw_invoice].[tranId],'Z','') = [vw_salesOrder].[customFieldList-custbody_legacy_sales_order]          -- 1745
      EXCEPT
      SELECT DISTINCT  
        baseSubscriptionId
      , subscriptionId
      , salesOrderInternalId
      , salesOrderNo
      , invoiceInternalId
      , REPLACE(invoiceNo,'Z','')
      FROM [xrf_legacy_invoice_salesorder]   


      SELECT DISTINCT 
        [vw_custom_subscription].[customFieldList-custrecord_base_subscription] AS 'baseSubscriptionId'
      , [vw_custom_subscription].[internalId] AS 'subscriptionId'
      , [vw_salesOrder].[internalId] AS 'salesOrderId'
      , [vw_salesOrder].[tranId] AS 'salesOrderNo'
      , [vw_invoice].[internalId] AS 'invoiceId'
      , [vw_salesOrder].[customFieldList-custbody_legacy_sales_order] AS 'salesOrderInvNo'
      FROM [vw_custom_subscription] 
      LEFT OUTER JOIN [vw_salesorder] ON [vw_salesorder].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
      JOIN [vw_invoice] ON REPLACE([vw_invoice].[tranId],'Z','') = [vw_salesOrder].[customFieldList-custbody_legacy_sales_order]          -- 1745
      EXCEPT
      SELECT DISTINCT  
        baseSubscriptionId
      , subscriptionId
      , salesOrderInternalId
      , salesOrderNo
      , invoiceInternalId
      , REPLACE(invoiceNo,'Z','')
      FROM [xrf_legacy_invoice_salesorder]   


SELECT subscriptionId, COUNT(invoiceNo)
FROM (
SELECT DISTINCT 
  sub.[customFieldList-custrecord_base_subscription] AS 'baseSubscriptionId'
, sub.[internalId] AS 'subscriptionId'
, sub.[customFieldList-custrecord_subscription_transaction_no] AS 'subSalesOrderNo'
, sub.[customFieldList-custrecord_subscription_transaction] AS 'subSalesOrderId'
, sub.[customFieldList-custrecord_subscription_transaction_line] AS 'subSalesOrderLine'
, so.internalId AS 'salesOrderId'
, so.tranID AS 'salesOrderNo'
, inv.internalId AS 'invoiceId'
, REPLACE(inv.tranId,'Z','') AS 'invoiceNo'
FROM vw_salesOrder so
JOIN vw_invoice inv ON inv.otherRefNum = so.otherRefNum AND inv.[createdFrom-internalId] IS NULL
JOIN vw_custom_subscription sub ON sub.[customFieldList-custrecord_subscription_transaction] = so.internalId
) x
GROUP BY subscriptionId
HAVING COUNT(invoiceNo) != 1

SELECT * FROM xrf_index WHERE baseSubscriptionId = 129
SELECT * FROM dim_subscription 
WHERE baseSubscriptionId = 129
ORDER BY xrfIndexId, subscriptionId, isCreditMemo
SELECT * FROM [dbo].[vw_custom_subscription] WHERE [customFieldList-custrecord_base_subscription] = 129
SELECT * FROM dim_creditMemo WHERE creditMemoNo = 'CM6910001634'

SELECT * FROM dim_salesorder WHERE salesOrderId = 937474
SELECT * FROM vw_salesOrder WHERE internalId = '937474'
SELECT * FROM vw_salesOrder_itemList WHERE internalId = '937474'

SELECT * FROM fact_arr WHERE baseSubscriptionId = 129 ORDER BY xrfIndexId, subscriptionId, isCreditMemo

SELECT * FROM [dbo].[vw_custom_subscription] WHERE internalId IN 
( 3460, 4536, 430,1300, 3522, 8380, 10421 )

SELECT DISTINCT * FROM dim_salesOrder WHERE salesOrderId IN
( 5611534, 7140495, 937474, 2079800, 634183, 633821, 1028934 )
-- dups in dim_salesOrder 
-- 937474, 7140495, 1028934
-- single records in dim_salesOrder
-- 2079800, 634183, 633821, 5611534

SELECT DISTINCT * FROM dim_invoice WHERE subscriptionId IN ( 3460, 4536, 430,1300, 3522, 8380, 10421 )
-- dups in dim_invoice
-- 943977-3460, 1034910-3522, 

SELECT * FROM xrf_index WHERE subscriptionId IN 
( 3460, 4536, 430,1300, 3522, 8380, 10421 )
-- dups in xrf_index = 3460, 3522

 129	3460	CM6910001634	8
 272	4536	CM6910003791	4
 430	 430	CMZ00000561	    3
1300	1300	CMZ00001612	    3
3522	3522	CM6910000798	8
3702	8380	CM6910004545	4
5202	10421	CM6910005165	4

SubsId  salesOutId
3460    222099
        354817
3522    242326
        270913

       SELECT DISTINCT 
          CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_base_subscription]) AS 'baseSubscriptionId'
        , CONVERT(int,[vw_custom_subscription].[internalId]) AS 'subscriptionId'
        , TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric)  AS 'subsLine'
        , [vw_salesorder_itemlist].[line] AS 'salesOrderToSubsLine'
        , [vw_creditmemo].[internalId] AS 'creditMemoId'
        , [vw_custom_subscription].[customFieldList-custrecord_credit_memo] AS 'creditMemoNo' 
        , CAST([customFieldList-custrecord_base_subscription_flag] AS int) AS 'isBase'
        , ISNULL(CAST([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction] AS int),-1)  AS 'salesOrderId'
        , ISNULL(TRY_CAST(ISNULL([vw_invoice].[internalId],[xrf_legacy_invoice_salesorder].[invoiceInternalId]) AS int),-1) AS 'invoiceId'
        , TRY_CAST(ISNULL([vw_salesorder_itemlist].[customFieldList-custcol_line_id],1) AS numeric) AS 'salesOrderItemLineId'
        , TRY_CAST(ISNULL([vw_invoice_itemlist].[customFieldList-custcol_line_id],1) AS numeric) AS 'invItemLineId' 

        , ISNULL(CAST([vw_custom_sales_out].[internalId] AS int),-1) AS 'salesOutId'
        , ISNULL(TRY_CAST([vw_custom_sales_out].[customFieldList-custrecord_sales_out_original_line_num] AS int),1) AS 'salesOutLineId'
        , ISNULL(CAST([vw_salesorder_itemlist].[class-internalId] AS int),-1) AS 'classId'
        , ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_item]),-1) AS 'itemId'
        , ISNULL(CAST([vw_salesorder_itemlist].[item-internalId] AS int),-1) AS 'salesOrderItemId'
        , ISNULL(CAST([vw_invoice_itemlist].[item-internalId] AS int),-1) AS 'invItemId'

        , ISNULL([vw_salesOrder].[customFieldList-custbody_om_salesperson],-1) AS 'salesOrgId'
        , ISNULL(CAST([vw_salesorder].[customFieldList-custbody_bill_customer] AS int),-1) AS 'billCustomerId'
        , ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_end_customer]),-1) AS 'endCustomerId'
        FROM [vw_custom_subscription] 
        JOIN [vw_nonInventorySaleItem] ON [vw_nonInventorySaleItem].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_item] 
        LEFT OUTER JOIN [vw_creditmemo] ON [vw_custom_subscription].[customFieldList-custrecord_credit_memo] = [vw_creditmemo].[tranId]
        LEFT OUTER JOIN [vw_salesorder] ON [vw_salesorder].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
        LEFT OUTER JOIN [vw_salesorder_itemlist] ON [vw_salesorder_itemlist].[internalId] = [vw_salesorder].[internalId]
                    AND TRY_CAST(ISNULL([vw_salesorder_itemlist].[line],1) AS numeric) = TRY_CAST(ISNULL([vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line],1) AS numeric)  -- Added
        LEFT OUTER JOIN [vw_invoice] ON [vw_invoice].[createdFrom-internalId] = [vw_salesorder].[internalId]
        LEFT OUTER JOIN [xrf_legacy_invoice_salesorder] ON [xrf_legacy_invoice_salesorder].[salesOrderInternalId] = [vw_salesorder].[internalId] 
        JOIN [vw_invoice_itemlist] ON [vw_invoice_itemlist].[internalId] = ISNULL([vw_invoice].[internalId],[xrf_legacy_invoice_salesorder].[invoiceInternalId])  --[vw_invoice].[internalId] 
                    AND CAST([vw_invoice_itemlist].[item-internalId] AS int) = CAST([vw_salesorder_itemlist].[item-internalId] AS int)
                    AND TRY_CAST([vw_invoice_itemlist].[customFieldList-custcol_line_id] AS numeric) = TRY_CAST([vw_salesorder_itemlist].[customFieldList-custcol_line_id] AS numeric)   -- Added
        LEFT OUTER JOIN [vw_custom_sales_out] ON [vw_custom_sales_out].[customFieldList-custrecord_original_sales_order] =  [vw_salesorder_itemList].[internalId] 
                    AND [vw_custom_sales_out].[customFieldList-custrecord_sales_out_original_line_num] = [vw_salesorder_itemlist].[customFieldList-custcol_line_id]  -- Added
                    AND [vw_custom_sales_out].[customFieldList-custrecord_sales_out_amount] >= 0
WHERE [vw_custom_subscription].[internalId] IN ( 3460, 3522 )
--        LEFT OUTER JOIN [vw_customer] bill_cust ON ISNULL(CONVERT(int,bill_cust.[internalId]),-1) = ISNULL(CONVERT(int,[vw_salesorder].[customFieldList-custbody_bill_customer]),-1) 
--        LEFT OUTER JOIN [vw_customer] end_cust  ON ISNULL(CONVERT(int, end_cust.[internalId]),-1) = ISNULL(CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_subscription_end_customer]),-1)
        ORDER BY CONVERT(int,[vw_custom_subscription].[customFieldList-custrecord_base_subscription])
               , CONVERT(int,[vw_custom_subscription].[internalId])
        ;