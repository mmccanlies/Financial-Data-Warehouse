-- Query to insert results into ARR_Walk_Report_n table for analysis
-- DROP TABLE [rpt_arr_walk_201705]
GO
SELECT DISTINCT
  CONVERT(int,[dim_subscription].[BaseSubscriptionId]) AS 'baseSubscriptionId'
, CONVERT(int,[dim_subscription].[subscriptionId]) AS 'subscriptionId'
, [dim_subscription].BaseSubscription AS 'baseSubscription'
, [dim_subscription].subscription AS 'subscription'
, [dim_subscription].isBase AS 'isBase'
, [dim_subscription].RefType AS 'refType'
, [dim_subscription].refTypeId AS 'refTypeId'
, [dim_subscription].refTypeTxt AS 'refTypeTxt'
, [dim_subscription].tierId AS 'tier'
, [dim_subscription].tierLvl AS 'tierLvl'
, [dim_subscription].tierName AS 'tierName'
, [dim_subscription_details].seats AS 'seats'
, [dim_subscription_details].totalSeats AS 'totalSeats'
, [dim_subscription].featureType AS 'featureType'
, [dim_subscription].featureAmt AS 'featureAmt'
, [dim_salesorder].[soTermYrs] AS 'itemTermYrs'
, [dim_salesorder].[soTermMos] AS 'itemTermMos'
, [dim_salesorder].[soTermDays] AS 'itemTermDays'

, [dim_subscription].StartDate AS 'startDate'
, [dim_subscription].EndDate AS 'endDate'
, [dim_subscription].EntitledYrs AS 'entitledYrs'
, [dim_subscription].EntitledMos AS 'entitledMos'
, [dim_subscription].EntitledDays AS 'entitledDays'

, [dim_subscription].[invoiceDate] AS 'invoiceDate'
, [fact_arr].[invoiceAmt] AS 'invoiceAmt'

, [dim_salesorder].[soListPrice] AS 'listPrice'
, [dim_salesorder].[soListPricePerYr] AS 'listPricePerYr'
, [dim_salesorder].[soListPricePerMo] AS 'listPricePerMo'
, [dim_salesorder].[soListPricePerDay] AS 'listPricePerDay'

, [dim_salesorder].StdDiscount AS 'stdDiscount'
, [dim_salesorder].StdDiscAmtYrs AS 'stdDiscountYrs'
, [dim_salesorder].StdDiscAmtMos AS 'stdDiscountMos'
, [dim_salesorder].StdDiscAmtDays AS 'stdDiscountDays'
, [dim_salesorder].ORNDiscount AS 'ORNDiscount'
, [dim_salesorder].ORNDiscAmtYrs AS 'ORNDiscountYrs'
, [dim_salesorder].ORNDiscAmtMos AS 'ORNDiscountMos'
, [dim_salesorder].ORNDiscAmtDays AS 'ORNDiscountDays'
, [dim_salesorder].NSDDiscount AS 'NSDDiscount'
, [dim_salesorder].NSDDiscAmtYrs AS 'NSDDiscountYrs'
, [dim_salesorder].NSDDiscAmtMos AS 'NSDDiscountMos'
, [dim_salesorder].NSDDiscAmtDays AS 'NSDDiscountDays'
, [dim_subscription].NSDApprovalNo AS 'NSDApprovalNo'

, [dim_subscription].FeatureOrBase AS 'featureOrBase'
, [dim_product].[skuNo] AS 'skuNo'
, [dim_product].[skuDescription] AS 'skuDescription'
, [dim_product].[skuDurationYrs] AS 'skuDurationYrs'
, [dim_product].[skuSeats] AS 'skuSeats'
, [dim_product].[productClass] AS 'productClass'
, [dim_product].[productType] AS 'productType'
, [dim_product].[productFamily] AS 'productFamily'
, [dim_product].[productFamilyPL] AS 'productFamilyPL'

, [dim_salesorg].[geo] AS 'geo'
, [dim_salesorg].[region] AS 'region'
, [dim_salesorg].[subRegion] AS 'subRegion'
, [dim_salesorg].[territory] AS 'territory'
, [dim_salesorg].[salesPerson] AS 'salesPerson'

, [dim_customer].[catName] AS 'salesCategory'
, [dim_invoice].[BillToCustomerName] AS 'billToCustomerName'
, [dim_invoice].[BillToCustomerAddress] AS 'billToCustomerAddress'
, [dim_subscription].[endCustomerName] AS 'endCustomerName'
, [dim_subscription].[endCustomerAddr] AS 'endCustomerAddress'
, [dim_salesout].[outReseller] AS 'resellerName'
, NULL AS 'resellerAddr'

, [dim_salesorder].soBookingDate AS 'bookingDate'
, [dim_invoice].billingDate AS 'billingDate'
, [dim_salesout].[outDate] AS 'salesOutDate'   -- FROM dim_salesout
, [dim_salesorder].[salesOrderNo] AS 'salesOrderNo'
, [dim_invoice].[invoiceNo] AS 'invoiceNo'
, [dim_salesorder].[soCustomerPONo] AS 'customerPONo'
, [dim_subscription].[itemId]  AS 'itemId'

, [dim_subscription_details].[prefix]+[dim_subscription_details].[entitlementTerm]+[dim_subscription_details].[priceTerm] AS 'ARRCategory'
, [dim_subscription_details].[termDays]
, [dim_subscription_details].[invoiceAmount]
, [dim_subscription_details].[arrAmtPerYr]
, [dim_subscription_details].[totalArrAmtPerYr]
, [fact_arr].[creditAmt] AS 'creditAmt'
, [dim_subscription_details].[arrDelta] AS 'arrDelta'
, [dim_subscription_details].[arrAmtChg]
, [dim_subscription_details].[entitlementChg]
, [dim_subscription_details].[tierChg]
, [dim_subscription_details].[seatChg]
, [dim_subscription_details].[daysBtwPriorEndAndCurrStart]
, [dim_subscription_details].[daysTilExpiration]
, [dim_subscription_details].[termChg]
, [dim_subscription_details].[amplifyQty]
, [dim_subscription_details].[extremeQty]
, [dim_subscription_details].[vmrsQty]
, [dim_subscription_details].[recordingHrs]
, [dim_subscription_details].[newBase]
, [dim_subscription_details].[updateOrdr]
, [dim_subscription_details].[baseIdOrdr]
, [fact_arr].[isNew]
, [fact_arr].[isRenewal]
, [fact_arr].[isLateRenew]
, [fact_arr].[renewGapDays]
, [dim_subscription].[iscreditMemo]
, [fact_arr].[isFeature]
, [fact_arr].[isUpDngrade]
, [fact_arr].[isExpansion]
, [fact_arr].[isChurn]
 INTO [rpt_arr_walk_201705] 
FROM [dim_subscription]  WITH (NOLOCK) 
LEFT JOIN [dim_subscription_details] WITH (NOLOCK) ON [dim_subscription_details].[subscriptionId] = [dim_subscription].[subscriptionId] AND [dim_subscription_details].[isCreditMemo] = [dim_subscription].[isCreditMemo]
LEFT JOIN [fact_arr] WITH (NOLOCK) ON [dim_subscription].[subscriptionId] = [fact_arr].[subscriptionId] AND  [dim_subscription].[isCreditMemo] = [fact_arr].[isCreditMemo]
LEFT JOIN [dim_invoice] WITH (NOLOCK) ON [dim_invoice].[invoiceId] = [fact_arr].[invoiceId] AND [dim_invoice].[invItemLineId] = [fact_arr].[invItemLineId]
LEFT JOIN [dim_salesorder] WITH (NOLOCK) ON [dim_salesorder].[salesOrderId] = [fact_arr].[salesOrderId] AND [dim_salesorder].[salesOrderLine] = [fact_arr].[salesOrderItemLineId]
LEFT JOIN [dim_product] WITH (NOLOCK) ON [dim_product].[itemId] = [fact_arr].[itemId]
LEFT JOIN [dim_salesorg] WITH (NOLOCK) ON [dim_salesorg].[sourceId] = [fact_arr].[salesOrgId]
LEFT JOIN [dim_salesout] WITH (NOLOCK) ON [dim_salesout].[salesOutId] = [fact_arr].[salesOutId]
LEFT JOIN [dim_customer] WITH (NOLOCK) ON [dim_customer].[internalId] = [fact_arr].[billToCustomerId]
--WHERE [dim_subscription].[baseSubscriptionId] IN 
--( 57, 60, 167, 217, 352, 563, 580, 834, 837, 845, 1153, 1349, 1517, 1544, 3369, 3393, 3471, 3491, 3525, 3771, 4015, 4206, 4901, 5408, 6366 )
ORDER BY CONVERT(int,[dim_subscription].[baseSubscriptionId]), CONVERT(int,[dim_subscription].[subscriptionId]), isCreditMemo


