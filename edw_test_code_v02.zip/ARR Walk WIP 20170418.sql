




SELECT COUNT(*) FROM [rpt_arr_walk_1]

SELECT COUNT(*) FROM [rpt_arr_walk_2]


SELECT COUNT(*) FROM [rpt_arr_walk_2]
WHERE YEAR([invoiceDate])*100+MONTH([invoiceDate]) > 201701

WHERE [endYearMo] >= 201702

subscription invoiceDate
-- 9982      all
-- 1529     2017
-- 5071     2016

Feb-Mar Invoice Dates
382 Feb
604 Mar


credit memo 
credit upgrade

missing subscription calcs
-- arr where salesorders are not

missing subscriptions


