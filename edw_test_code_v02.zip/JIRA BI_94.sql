 -- BI-94 missing salesorders

SELECT COUNT(*) 
FROM [vw_custom_subscription] 
 JOIN [vw_salesorder_itemList] ON [vw_salesorder_itemList].[internalId] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction]
 AND  [vw_salesorder_itemList].[line] = [vw_custom_subscription].[customFieldList-custrecord_subscription_transaction_line]
--9205

SELECT COUNT(DISTINCT internalId) FROM [vw_custom_subscription]
-- 9206

SELECT COUNT(DISTINCT internalId) FROM [vw_custom_subscription] WHERE [customFieldList-custrecord_credit_memo] IS NOT NULL
WHERE [customFieldList-custrecord_subscription_transaction_line] IS NULL
-- 120

SELECT COUNT(*) 
FROM [vw_custom_subscription]
JOIN [vw_creditMemo] ON [vw_creditMemo].[tranId]  = [vw_custom_subscription].[customFieldList-custrecord_credit_memo]
WHERE [customFieldList-custrecord_subscription_transaction_line] IS NOT NULL

SELECT COUNT(DISTINCT [customFieldList-custrecord_subscription_transaction]) FROM [vw_custom_subscription]
-- 8779

SELECT DISTINCT [customFieldList-custrecord_subscription_transaction] FROM [vw_custom_subscription]
EXCEPT
SELECT DISTINCT [internalId] FROM [vw_salesorder]

SELECT COUNT(DISTINCT subscriptionId) FROM [dim_subscription]
-- 9410        9164 distinct
SELECT COUNT(DISTINCT subscriptionId) FROM [dim_subscription_details] WHERE subscriptionId = baseSubscriptionId
-- 9183         8978 distinct       4595 base

SELECT COUNT(*) FROM [vw_custom_subscription] 
WHERE [customFieldList-custrecord_subscription_transaction_line] IS NULL
-- 1 null transaction, 120 null transaction_lines

SELECT COUNT(*) FROM xrf_index WHERE salesOrderItemId IS NULL
-- 0

SELECT COUNT(*) FROM [dim_salesorder] WHERE [salesOrderNo] IS NULL
--150

SELECT COUNT(*) FROM [vw_salesorder] WHERE [tranId] IS NULL
--0

SELECT DISTINCT so.SalesOrderId, sol.[customFieldList-custcol_line_id]
FROM [dim_salesorder] so
JOIN [vw_salesorder_itemList] sol ON sol.internalId = so.salesOrderId
WHERE CONVERT(numeric,sol.[customFieldList-custcol_line_id]) != 1
-- 865

SELECT COUNT(*) FROM dim_subscription WHERE salesOrderId IS NULL
-- No null salesOrderId's or salesOrderLines in dim_subscription

SELECT COUNT(*) FROM dim_subscription WHERE subscriptionId = baseSubscriptionId
-- 5190

SELECT COUNT(DISTINCT subscriptionId) FROM [dim_subscription]
-- 9164 distinct subscriptionId's (excludes CM's)

SELECT COUNT(*) FROM dim_subscription_details
WHERE isCreditMemo = 1
-- 8978 distinct subscriptionId's compared to 9164 in dim_subscription  there are 9183 lines in subscription_details


SELECT COUNT(*) FROM [rpt_arr_walk_1] 

SELECT * FROM [rpt_arr_walk_1] 
WHERE [ListPrice] IS NULL
[salesOrderNo] IS NULL

SELECT DISTINCT 
  [dim_subscription].[subscriptionId]
, dim_subscription_details.subscriptionId
, [fact_arr].[subscriptionId]
, [fact_arr].[xrfIndexId] 
, [dim_invoice].[invoiceId], [dim_invoice].[invItemId]
, [dim_salesorder].[salesOrderId], [dim_salesorder].[salesOrderLine], [dim_salesorder].[salesOrderNo]
FROM [dim_subscription]  WITH (NOLOCK) 
JOIN [dim_subscription_details] WITH (NOLOCK) ON [dim_subscription_details].[subscriptionId] = [dim_subscription].[subscriptionId] AND [dim_subscription_details].[isCreditMemo] = [dim_subscription].[isCreditMemo]
LEFT JOIN [fact_arr] WITH (NOLOCK) ON [dim_subscription].[subscriptionId] = [fact_arr].[subscriptionId] AND  [dim_subscription].[isCreditMemo] = [fact_arr].[isCreditMemo]
LEFT JOIN [dim_invoice] WITH (NOLOCK) ON [dim_invoice].[invoiceId] = [fact_arr].[invoiceId] AND [dim_invoice].[invItemLineId] = [fact_arr].[invItemLineId]
LEFT JOIN [dim_salesorder] WITH (NOLOCK) ON [dim_salesorder].[salesOrderId] = [fact_arr].[salesOrderId] AND [dim_salesorder].[salesOrderLine] = [fact_arr].[salesOrderItemLineId]
WHERE dim_subscription_details.subscriptionId IS NULL

                        distinct
                        LEFT JOIN    distinct Id''s         distinct 
-- dim_subscription        9410             9164                    9164
--+ _details               9450             8978    diff: 186       8978    diff: 186
--+ fact_arr               9582             8978                    8991    diff: 173
--+ dim_invoice            9952             8978                    8991
--+ dim_salesorder                          8978                    8991



SELECT COUNT(*) FROM [dbo].[rpt_arr_walk_2]
--9982
SELECT COUNT(*) FROM [dbo].[rpt_arr_walk_2] WHERE invoiceAmount IS NULL
-- 224
SELECT COUNT(*) FROM [dbo].[rpt_arr_walk_2] WHERE arrAmtPerYr IS NULL
-- 224
SELECT COUNT(*) FROM [dbo].[rpt_arr_walk_2] WHERE arrDelta IS NULL
-- 224

SELECT * FROM [dbo].[rpt_arr_walk_2] WHERE arrAmtPerYr IS NULL



