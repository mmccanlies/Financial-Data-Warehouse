--GO
/***************************************************************************************************************************
**                                        CREATE INDEXES ON TOP OF SOURCE TABLES
** by: mmccanlies       03/16/2017
** 
***************************************************************************************************************************/
GO
USE [fdw_raw]
GO

--IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_salesOrder_line' )
--    DROP INDEX [NCI_ns_salesOrder_line] ON [fdw_raw].[ns_salesOrder] 
--GO
--CREATE NONCLUSTERED INDEX NCI_ns_salesOrderItemList_line ON [ns_salesOrder_ItemList] ( [internalId], [line], [item-internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_salesOrder_billCustomer' )
    DROP INDEX [NCI_ns_salesOrder_line] ON [fdw_raw].[ns_salesOrder] 
GO
CREATE NONCLUSTERED INDEX NCI_ns_salesOrder_billCustomer ON [fdw_raw].[ns_salesOrder] ( [customFieldList-custbody_bill_customer] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_subscription_endCustomer' )
    DROP INDEX [NCI_ns_subscription_endCustomer] ON [fdw_raw].[ns_custom_subscription]
GO
CREATE NONCLUSTERED INDEX NCI_ns_subscription_endCustomer ON [fdw_raw].[ns_custom_subscription] ( [customFieldList-custrecord_subscription_end_customer] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_salesOrderItemList_line' )
    DROP INDEX [NCI_ns_salesOrderItemList_line] ON [fdw_raw].[ns_salesOrder_itemList]
GO
CREATE NONCLUSTERED INDEX NCI_ns_salesOrderItemList_line ON [fdw_raw].[ns_salesOrder_ItemList] ( [internalId], [customFieldList-custcol_line_id], [item-internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_vw_salesOrderItemList_itemId' )
    DROP INDEX [NCI_vw_salesOrderItemList_itemId] ON [fdw_raw].[ns_salesOrder_itemList]
GO
CREATE NONCLUSTERED INDEX NCI_vw_salesOrderItemList_itemId ON [fdw_raw].[ns_salesOrder_ItemList] ( [item-internalId] ) 
INCLUDE ( [internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_invoice_createdFromId' )
    DROP INDEX [NCI_ns_invoice_createdFromId] ON [fdw_raw].[ns_invoice] 
GO
CREATE NONCLUSTERED INDEX NCI_ns_invoice_createdFromId ON [fdw_raw].[ns_invoice] ( [createdFrom-internalId], [tranId] )
INCLUDE ( [internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_invoiceItemList_line' )
    DROP INDEX [NCI_ns_invoiceItemList_line] ON [fdw_raw].[ns_invoice_ItemList]
GO
CREATE NONCLUSTERED INDEX NCI_ns_invoiceItemList_line ON [fdw_raw].[ns_invoice_ItemList] ( [internalId], [customFieldList-custcol_line_id], [item-internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_invoiceItemList_itemId' )
    DROP INDEX [NCI_ns_invoiceItemList_itemId] ON [fdw_raw].[ns_invoice_ItemList]
GO
CREATE NONCLUSTERED INDEX NCI_ns_invoiceItemList_itemId ON [fdw_raw].[ns_invoice_ItemList] ( [item-internalId] )
INCLUDE ( [internalId] )
GO

IF EXISTS ( SELECT COUNT(*) FROM [sys].[indexes] WHERE name = 'NCI_ns_customsalesout_salesorder' )
    DROP INDEX [NCI_ns_customsalesout_salesorder] ON [fdw_raw].[ns_custom_sales_out] 
GO
CREATE NONCLUSTERED INDEX NCI_ns_customsalesout_salesorder ON [fdw_raw].[ns_custom_sales_out] ( [customFieldList-custrecord_original_sales_order], [customFieldList-custrecord_sales_out_original_line_num]  )
INCLUDE ( [internalId] )



USE [sandbox_mike]
/***************************************************************************************************************************
**                                        BUILD VIEWS ON TOP OF SOURCE TABLES
** by: mmccanlies       03/07/2017
** 
***************************************************************************************************************************/
GO
IF object_id('vw_custom_subscription', 'v') IS NOT NULL
DROP VIEW vw_custom_subscription 
GO
CREATE VIEW vw_custom_subscription 
AS
SELECT 
  [internalId]
, [customRecordId]
, [customFieldList-custrecord_base_subscription]
, [customFieldList-custrecord_base_subscription_flag]
, [customFieldList-custrecord_credit_memo]
, [customFieldList-custrecord_reference_type]
, [customFieldList-custrecord_number_of_seats_2]
, [customFieldList-custrecord_number_of_seats]
, [customFieldList-custrecord_license_type]
, [customFieldList-custrecord_amplify_hours]
, [customFieldList-custrecord_recording_hours]
, [customFieldList-custrecord_sub_recording_hrs_included]
, [customFieldList-custrecord_total_recording_hours]
, [customFieldList-custrecord_vmrs]
, [customFieldList-custrecord_subscription_cloud_features]
, [customFieldList-custrecord_subscription_start_date]
, [customFieldList-custrecord_subscription_end_date]
, [customFieldList-custrecord_subscription_cost]
, [customFieldList-custrecord_standard_discount_pct]
, [customFieldList-custrecord_orn_discount_pct]
, [customFieldList-custrecord_nsd_discount_pct]
, [customFieldList-custrecord_nsd_id]
, [customFieldList-custrecord_subscription_tier]
, [customFieldList-custrecord_subscription_item_no]
, [customFieldList-custrecord_subscription_item]
, [customFieldList-custrecord_item_type]
, [customFieldList-custrecord_subscription_bill_to_customer]
, [customFieldList-custrecord_subscription_end_customer]
, [customFieldList-custrecord_subscription_transaction]
, [customFieldList-custrecord_subscription_transaction_line]
, [customFieldList-custrecord_subscription_transaction_no]
, [customFieldList-custrecord_subscription_status]
, [customFieldList-custrecord_sf_quote_id]
, [customFieldList-custrecord_current_so_text]
, [DBcreated]
, [DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_custom_subscription]
/*
WHERE [customFieldList-custrecord_base_subscription] IN 
( '131', '359', '663', '738', '757', '761', '780', '788', '791', '805', '840', '867', '870', '871', '902', '907'
, '914', '920', '925', '944', '962', '1047', '1140', '1144', '1348', '1511', '3702', '4334', '4538', '4600'
, '4698', '4719', '4833', '4880', '4883', '4939', '4941', '4985', '4987', '4993', '5042', '5043', '5048'
, '5050', '5087', '5094', '5098', '5119', '5122', '5129', '5131', '5159', '5163', '5167', '5189', '5219'
, '5222', '5238', '5286', '5298', '5344', '5374', '5389', '5393', '5400', '5420', '5444', '5512', '5578'
, '5591', '5653', '5657', '5874', '6042', '6300', '6648', '6936', '7583', '7597', '8113', '8141', '9446'
, '9472', '9790', '9798', '9799', '9807', '9815', '9816', '9825', '9828', '9833', '9836', '9838', '9844'
, '9846', '9847', '9852', '9855', '9859', '9862', '9865', '9866', '9867', '9869', '9870', '9871', '9872'
, '9885', '9887', '9888', '9900', '9904', '9906', '9907', '9908', '9909', '9916', '9918', '9924', '9925'
, '9927', '9928', '9933', '9934', '9938', '9940', '9942', '9944', '9946' )
*/
GO


GO
IF object_id('vw_salesOrder', 'v') IS NOT NULL
DROP VIEW [vw_salesOrder]
GO
CREATE VIEW [vw_salesOrder]
AS
SELECT 
  [ns_salesOrder].[internalId]
, [ns_salesOrder].[tranId]
, [ns_salesOrder].[tranDate]
, [ns_salesOrder].[customFieldList-custbody_order_date]
, [ns_salesOrder].[otherRefNum]
, [ns_salesOrder].[customFieldList-custbody_transaction_case]
, [ns_salesOrder].[customFieldList-custbody_om_salesperson]
, [ns_salesorder].[subsidiary-name]
, [ns_salesorder].[customFieldList-custbody_bill_customer]
, [ns_salesOrder].[customFieldList-custbody_tno_order_type]
, [ns_salesOrder].[customFieldList-custbody_legacy_sales_order]
, [ns_salesOrder].[customFieldList-custbody_legacy_oracle_so_id]
, [ns_salesOrder].[customFieldList-custbody_legacy_oracleid]
, [ns_salesorder].[entity-internalId]
, [ns_salesorder].[entity-name]
, [ns_salesOrder].[total]
, [ns_salesorder].[lastModifiedDate]
, [DBlastmodified]
, [DBcreated]
FROM [fdw_raw].[fdw_raw].[ns_salesOrder]


GO
IF object_id('vw_salesOrder_itemList', 'v') IS NOT NULL
DROP VIEW [vw_salesOrder_itemList]
GO
CREATE VIEW [vw_salesOrder_itemList]
AS
SELECT 
  [ns_salesOrder_itemlist].[internalId]
, [ns_salesOrder_itemlist].[line]
, [ns_salesOrder_itemList].[item-name]
, [ns_salesOrder_itemList].[item-internalId]
, [ns_salesOrder_ItemList].[class-name]
, [ns_salesOrder_ItemList].[class-internalId]
, [ns_salesOrder_itemList].[location-name]
, [ns_salesOrder_itemList].[description]
, [ns_salesOrder_itemList].[customFieldList-custcol_service_start_date]
, [ns_salesOrder_itemList].[customFieldList-custcol_service_end_date]
, [ns_salesOrder_itemList].[units-name]
, [ns_salesOrder_itemList].[quantity]
, [ns_salesOrder_itemList].[amount]
, [ns_salesOrder_itemList].[price-name]
, [ns_salesOrder_itemList].[customFieldList-custcol_request_date]
, [ns_salesOrder_itemlist].[customFieldList-custcol_term]
, [ns_salesOrder_ItemList].[customFieldList-custcol_custlistprice]
, [ns_salesOrder_itemList].[customFieldList-custcolcustcolcustcol_custactdiscount]
, [ns_salesOrder_itemList].[quantityBilled]
, [ns_salesOrder_itemList].[quantityFulfilled]
, [ns_salesOrder_itemList].[customFieldList-custcol_service_renewal]
, [ns_salesOrder_itemList].[department-name]
, [ns_salesOrder_itemList].[revRecStartDate]
, [ns_salesOrder_itemList].[revRecEndDate]
, [ns_salesOrder_itemList].[revRecTermInMonths]
, [ns_salesOrder_itemlist].[customFieldList-custcol_service_ref_type]
, [ns_salesOrder_itemList].[customFieldList-custcol_install_base]
, [ns_salesOrder_itemlist].[customFieldList-custcol_ib_base_description]
, [ns_salesOrder_itemlist].[customFieldList-custcol_serial]
, [ns_salesOrder_itemlist].[customFieldList-custcol_rma_container_item]
, [ns_salesOrder_itemlist].[customFieldList-custcol_rma_price]
, [ns_salesOrder_itemList].[isClosed]
, [ns_salesOrder_itemlist].[customFieldList-custcol_line_id]
, [DBcreated]
, [DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_salesOrder_itemList]



GO
IF object_id('vw_creditMemo', 'v') IS NOT NULL
DROP VIEW [vw_creditMemo]
GO
CREATE VIEW [dbo].[vw_creditMemo]
AS
SELECT
  [ns_creditmemo].[internalId]
, [ns_creditmemo].[tranId]
, [ns_creditmemo].[tranDate]
, [ns_creditMemo].[salesEffectiveDate]
, [ns_creditMemo].[customFieldList-custbody_order_date]
, [ns_creditMemo].[postingPeriod-name]
, [ns_creditmemo].[createdFrom-internalId]
, [ns_creditmemo].[createdFrom-name]
, [ns_creditMemo].[customFieldList-custbody_rma_sales_order]
, [ns_creditMemo].[customFieldList-custbody_receipt]
, [ns_creditMemo].[entity-name]
, [ns_creditMemo].[recognizedRevenue]
, [ns_creditMemo].[applied]
, [ns_creditMemo].[unapplied]
, [ns_creditMemo].[total]
, [ns_creditMemo].[lastModifiedDate]
, [ns_creditMemo].[DBcreated]
, [ns_creditMemo].[DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_creditMemo]


GO
IF object_id('vw_creditMemo_itemList', 'v') IS NOT NULL
DROP VIEW [vw_creditMemo_itemList]
GO
CREATE VIEW [vw_creditMemo_itemList]
AS
SELECT
  [ns_creditmemo_ItemList].[internalId]
, [ns_creditmemo_ItemList].[line]
, [ns_creditmemo_ItemList].[customFieldList-custcol_line_id]
, [ns_creditmemo_ItemList].index1
, [ns_creditmemo_ItemList].[class-internalId]
, [ns_creditmemo_ItemList].[class-name]
, [ns_creditmemo_ItemList].[item-internalId]
, [ns_creditmemo_ItemList].[item-name]
, [ns_creditmemo_ItemList].[description]
, [ns_creditmemo_ItemList].[price-name]
, [ns_creditmemo_ItemList].[quantity]
, [ns_creditmemo_ItemList].[units-name]
, [ns_creditmemo_ItemList].[rate]
, [ns_creditmemo_ItemList].[amount]
, [ns_creditmemo_ItemList].[customFieldList-custcol_custlistprice]
, [ns_creditmemo_ItemList].[customFieldList-custcolcustcolcustcol_custactdiscount]
, [ns_creditmemo_ItemList].[customFieldList-custcol_discount_comment]
, [ns_creditmemo_ItemList].[customFieldList-custcol_cost]
, [ns_creditmemo_ItemList].[customFieldList-custcol_ava_incomeaccount]
, [ns_creditmemo_ItemList].[department-name]
, [ns_creditmemo_ItemList].[location-name]
, [ns_creditmemo_ItemList].[customFieldList-custcol_install_base]
, [ns_creditmemo_ItemList].[customFieldList-custcol_install_base_item]
, [ns_creditmemo_ItemList].[customFieldList-custcol_sales_rep]
, [ns_creditmemo_ItemList].[DBcreated]
, [ns_creditmemo_ItemList].[DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_creditMemo_itemList]


GO
IF object_id('vw_invoice', 'v') IS NOT NULL
DROP VIEW [vw_invoice]
GO
CREATE VIEW [vw_invoice]
AS
SELECT
  [ns_invoice].[internalId]
, [ns_invoice].[createdFrom-internalId]
, [ns_invoice].[createdFrom-name]
, [ns_invoice].[customFieldList-custbody_legacy_sales_order]
, [ns_invoice].[customFieldList-custbody_legacy_oracle_so_id]
, [ns_invoice].[customFieldList-custbody_legacy_oracleid]
, [ns_invoice].[tranId]
, [ns_invoice].[tranDate]
, [ns_invoice].[customFieldList-custbody_bill_customer]
, [ns_invoice].[entity-name]
, [ns_invoice].[billAddress] 
, [ns_invoice].[customFieldList-custbody_order_date]
, [ns_invoice].[customFieldList-custbody_om_salesperson]
, [ns_invoice].[total]
, [ns_invoice].[customFieldList-custbody_rma_sales_order]
, [ns_invoice].[otherRefNum]
, [DBcreated]
, [DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_invoice]


GO
IF object_id('vw_invoice_itemList', 'v') IS NOT NULL
DROP VIEW [vw_invoice_itemList]
GO
CREATE VIEW [vw_invoice_itemList]
AS
SELECT
  [ns_invoice_itemlist].[internalId]
, [ns_invoice_itemlist].[customFieldList-custcol_line_id]
, [ns_invoice_itemlist].[orderLine]
, [ns_invoice_itemList].[customFieldList-custcol_term]
, [ns_invoice_itemList].[customFieldList-custcol_service_start_date]
, [ns_invoice_itemList].[customFieldList-custcol_service_end_date]
, [ns_invoice_ItemList].[customFieldList-custcol_install_base]
, [ns_invoice_ItemList].[customFieldList-custcol_install_base_item]
, [ns_invoice_ItemList].[customFieldList-custcol_serial]
, [ns_invoice_itemlist].[class-name]    
, [ns_invoice_itemlist].[item-name]     
, [ns_invoice_itemlist].[description]   
, [ns_invoice_ItemList].[location-name] 
, [ns_invoice_ItemList].[rate]
, [ns_invoice_ItemList].[quantity]
, [ns_invoice_itemlist].[units-name]
, [ns_invoice_itemlist].[price-name]
, [ns_invoice_ItemList].[customFieldList-custcol_cost]
, [ns_invoice_itemlist].[customFieldList-custcol_ava_incomeaccount]
, [ns_invoice_itemlist].[revRecStartDate]
, [ns_invoice_itemlist].[revRecEndDate]
, [ns_invoice_itemlist].[revRecSchedule-name]
, [ns_invoice_itemlist].[customFieldList-custcol_subscription]
, [ns_invoice_ItemList].[subscriptionLine-internalId]
, [ns_invoice_ItemList].[subscriptionLine-name]
, [ns_invoice_itemlist].[customFieldList-custcol_auto_sales_out]
, [ns_invoice_ItemList].[item-internalId]
, [ns_invoice_ItemList].[customFieldList-custcol_sales_rep]
, [ns_invoice_ItemList].[customFieldList-custcol_reseller]
, [ns_invoice_ItemList].[customFieldList-custcol_custlistprice]
, [ns_invoice_ItemList].[customFieldList-custcol_standard_discount_pct]
, [ns_invoice_ItemList].[customFieldList-custcol_nsd_discount_pct]
, [ns_invoice_ItemList].[customFieldList-custcol_orn_discount_pct]
, [ns_invoice_ItemList].[customFieldList-custcolcustcolcustcol_custactdiscount]
, [DBcreated]
, [DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_invoice_itemList]


GO
IF object_id('vw_custom_sales_out', 'v') IS NOT NULL
DROP VIEW [vw_custom_sales_out]
GO
CREATE VIEW [vw_custom_sales_out]
AS
SELECT
  [ns_custom_sales_out].[internalId]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_original_line_num]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_date]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_purchasedate]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_install_base]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_serial_number]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_status]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_item]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_quantity]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_amount]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_list_price]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_sold_thru_reseller]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_strategic_reseller]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_reseller_po_number]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_customer_number]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_company_name]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_address_1]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_address_2]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_address_3]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_address_4]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_city]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_state]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_zip]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_province]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_county]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_country]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_email]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_phone]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_sf_partner_number]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_sales_region]
, [ns_custom_sales_out].[customFieldList-custrecordsales_out_region_override]
, [ns_custom_sales_out].[customFieldList-custrecord_sales_out_original_trans]
, [ns_custom_sales_out].[customFieldList-custrecord_original_sales_order]
, [ns_custom_sales_out].[externalId]
, [DBcreated]
, [DBlastmodified]
FROM [fdw_raw].[fdw_raw].[ns_custom_sales_out]


GO
IF object_id('vw_customer', 'v') IS NOT NULL
DROP VIEW [vw_customer]
GO
CREATE VIEW [vw_customer]
AS
SELECT
  internalId
, [billingInternalId]
, [entityId]
, [companyName]
, [defaultAddress]
, [emailDomain]
, [billingAddressee]
, [billingAddr1]
, [billingAddr2]
, [billingAddr3]
, [billingCity]
, [billingState]
, [billingZip]
, [billingCountry]
, [billingAddrText]
, [billingLabel]
, [category-internalId]
, [category-name]
, [subsidiary-internalId]
, [subsidiary-name]
, [phone]
, [fax]
, [email]
, [terms-internalId]
, [terms-name]
, [currency-name]
, [stage]
, [entityStatus-name]
, [externalId]
, [lastModifiedDate]
FROM [fdw_raw].[fdw_raw].[ns_customer]


GO
IF object_id('vw_nonInventorySaleItem', 'v') IS NOT NULL
DROP VIEW [vw_nonInventorySaleItem]
GO
CREATE VIEW [vw_nonInventorySaleItem]
AS
SELECT
  [class-internalId]
, [internalId]
, [class-name]
, [itemId]
, [salesDescription]
, [customFieldList-custitem_term]
, [customFieldList-custitem_number_of_seats]
, [customFieldList-custitem_recording_hours]
, [customFieldList-custitem_vmrs_included]  
, [saleUnit-name]
, [externalId]
, [createdDate]
, [lastModifiedDate]
FROM [fdw_raw].[fdw_raw].[ns_nonInventorySaleItem]


GO
IF object_id('vw_returnAuthorization', 'v') IS NOT NULL
DROP VIEW [vw_returnAuthorization]
GO
CREATE VIEW [vw_returnAuthorization]
AS
SELECT
  [internalId]
, [tranDate]
, [tranId]
, [createdFrom-internalId]
, [createdFrom-name]
, [class-internalId]
, [class-externalId]
, [class-type]
, [class-name]
, [subTotal]
, [discountTotal]
, [total]
, [revenueStatus]
, [status]
, [customFieldList-custbody_ava_customercompanyname]
, [customFieldList-custbody_bill_customer]
, [billingAddress-addrText]
, [customFieldList-custbody_end_customer]
, [customFieldList-custbody_end_customer_address_text]
, [customFieldList-custbody_receipt]
, [otherRefNum]
, [entity-internalId]
, [entity-name]
, [memo]
, [customFieldList-custbody_custom_return_reason]
, [customFieldList-custbody_om_salesperson]
, [customFieldList-custbody_rma_sales_order]
, [createdDate]
, [lastModifiedDate]
FROM [fdw_raw].[fdw_raw].[ns_returnAuthorization]
GO


IF object_id('vw_returnAuthorization_itemList', 'v') IS NOT NULL
DROP VIEW [vw_returnAuthorization_itemList]
GO
CREATE VIEW [vw_returnAuthorization_itemList]
AS
SELECT
  [internalId]
, [line]
, [customFieldList-custcol_line_id]
, [description]
, [quantity]
, [quantityReceived]
, [quantityBilled]
, [units-name]
, [price-name]
, [rate]
, [amount]
, [class-internalId]
, [class-name]
, [customFieldList-custcol_service_renewal]
, [customFieldList-custcol_custlistprice]
, [customFieldList-custcol_rma_price]
, [customFieldList-custcolcustcolcustcol_custactdiscount]
, [DBcreated]
, [DBlastModified]
FROM [fdw_raw].[fdw_raw].[ns_returnAuthorization_itemList]



IF object_id('vw_custom_defaultsalesperson', 'v') IS NOT NULL
DROP VIEW [vw_custom_defaultsalesperson]
GO
CREATE VIEW [ns_custom_defaultSalesperson]
AS
SELECT *
FROM [fdw_raw].[fdw_raw].[ns_custom_defaultSalesperson]



IF object_id('vw_custom_installedBase', 'v') IS NOT NULL
DROP VIEW [vw_custom_installedBase]
GO
CREATE VIEW [vw_custom_installedBase]
AS
SELECT 
  [internalId]
, [name]
, [owner-internalId]
, [owner-name]
, [recType-internalId]
, [recType-name]
, [externalId]
, [customFieldList-custrecord_ib_serial_number]
, [customFieldList-custrecord_parent_installed_base]
, [customFieldList-custrecord_ib_item_description]
, [customFieldList-custrecord_ib_ship_from]
, [customFieldList-custrecord_ib_status]
, [customFieldList-custrecord_ib_owner]
, [customFieldList-custrecord_ib_current_locaiton]
, [customFieldList-custrecord_ib_installed_at]
, [customFieldList-custrecord_ib_install_date]
, [customFieldList-custrecord_ib_original_so]
, [customFieldList-custrecord_ib_original_so_line]
, [customFieldList-custrecord_so_po_number]
, [customFieldList-custrecord_non_serial_recognized]
, [customFieldList-custrecord_ib_ams_portal_end_date]
, [customFieldList-custrecord_ib_ams_diff_end_days]
, [customFieldList-custrecord_license_type_cluster]
, [customFieldList-custrecord_license_type_expanded]
, [customFieldList-custrecord_license_type_dualdisplay]
, [customFieldList-custrecord_license_type_1080p]
, [customFieldList-custrecord_num_seats]
, [customFieldList-custrecord_primary_serial_number]
, [customFieldList-custrecord_ib_instance_no]
, [customFieldList-custrecord_ib_po_number]
, [customFieldList-custrecord_ib_so_no]
, [customFieldList-custrecord_ib_so_line_no]
, [customFieldList-custrecord_legacy_oem_type]
, [customFieldList-custrecord_ib_standard_warranty_start]
, [customFieldList-custrecord_ib_standard_warranty_end]
, [customFieldList-custrecord_ib_standard_warranty_term]
, [customFieldList-custrecord_exended_warranty_start]
, [customFieldList-custrecord_exended_warranty_end]
, [customFieldList-custrecord_advanced_warranty_start]
, [customFieldList-custrecord_advanced_warranty_end]
, [customFieldList-custrecord_ib_ams_start_date]
, [customFieldList-custrecord_ib_ams_end_date]
, [customFieldList-custrecord_ib_ams_term]
, [customFieldList-custrecord_ib_warranty_class]
, [customFieldList-custrecord_ib_owner_name]
, [customFieldList-custrecord_ib_salesordernumber]
, [customFieldList-custrecord_ib_itemnumber]
, [customFieldList-custrecord_ib_item]
, [customFieldList-custrecord_ib_primarycomponent]
, [customFieldList-custrecord_ib_item_type]
, [customFieldList-custrecord_clean_up]
, [customFieldList-custrecord_processed]
, [parent-internalId]
, [parent-externalId]
, [parent-type]
, [parent-name]
, [altName]
, [isInactive]
, [customFieldList-custrecord_ib_date_created]
, [created]
, [lastModified]
FROM [fdw_raw].[fdw_raw].ns_custom_installedBase ib
GO

IF object_id('vw_custom_servicecontract', 'v') IS NOT NULL
DROP VIEW [vw_custom_servicecontract]
GO
CREATE VIEW [vw_custom_servicecontract] 
AS
SELECT DISTINCT 
  [internalId]
, [externalId]
, [customRecordId]
, [owner-internalId]
, [recType-internalId]
, [recType-name]
, [customFieldList-custrecord_sc_start_date]
, [customFieldList-custrecord_sc_end_date]
, [customFieldList-custrecord_sc_type]
, [customFieldList-custrecord_sc_origination_transaction]
, [customFieldList-custrecord_sc_origination_trans_line]
, [customFieldList-custrecord_sc_item]
, [customFieldList-custrecord_item_uom]
, [customFieldList-custrecord_item_service_coverage]
, [customFieldList-custrecord_legacy_contract_number]
, [customFieldList-custrecord_sc_email_date]
, [customFieldList-custrecord_sc_resend_email]
, isInactive
FROM [fdw_raw].[fdw_raw].ns_custom_servicecontract
GO



IF object_id('vw_custom_servicecontractline', 'v') IS NOT NULL
	DROP VIEW [dbo].[vw_custom_servicecontractline]
GO

CREATE VIEW [dbo].[vw_custom_servicecontractline]
AS
SELECT DISTINCT
  [internalId]
, [externalId]
, [customRecordId]
, [recType-internalId]
, [recType-name]
, [customFieldList-custrecord_scl_service_contract]
, [customFieldList-custrecord_scl_ib_original_so]
, [customFieldList-custrecord_scl_install_base]
, [customFieldList-custrecord_scl_ib_serial_number]
, [name]
, [customFieldList-custrecord_scl_ib_item]
, [customFieldList-custrecord_scl_ib_item_description]
, [customFieldList-custrecord_scl_rate]
, [customFieldList-custrecord_scl_quantity]
, [customFieldList-custrecord_scl_listprice]
, [customFieldList-custrecord_scl_ib_sales_rep]
, [customFieldList-custrecord_scl_ib_reseller_flag]
, [customFieldList-custrecord_scl_ib_reseller_name]
, [customFieldList-custrecord_scl_ib_so_partner_number]
, [customFieldList-custrecord_scl_ib_address_1]
, [customFieldList-custrecord_scl_ib_address_2]
, [customFieldList-custrecord_scl_ib_city]
, [customFieldList-custrecord_scl_ib_state]
, [customFieldList-custrecord_scl_ib_zip]
, [customFieldList-custrecord_scl_ib_contact]
, [customFieldList-custrecord_scl_ib_phone]
, [customFieldList-custrecord_scl_ib_email]
, [customFieldList-custrecord_scl_return_authorization]
, [customFieldList-custrecord_scl_ib_rma]
, [customFieldList-custrecord_scl_ib_owner]
, [owner-name]
, [customFieldList-custrecord_scl_ib_end_user]
, [customFieldList-custrecord_scl_ib_installed_at]
, [customFieldList-custrecord_scl_ib_install_date]
, [customFieldList-custrecord_scl_ib_current_location]
, [customFieldList-custrecord_scl_ib_license_type]
, [customFieldList-custrecord_scl_ib_po_number]
, [customFieldList-custrecord_scl_ib_so_no]
, [customFieldList-custrecord_scl_ib_standard_start]
, [customFieldList-custrecord_scl_ib_standard_end]
, [customFieldList-custrecord_scl_ib_standard_term]
, [customFieldList-custrecord_scl_ib_software_start]
, [customFieldList-custrecord_scl_ib_software_end]
, [customFieldList-custrecord_scl_ib_software_term]
, [customFieldList-custrecord_termination_date]
, [customFieldList-custrecord_scl_ib_ams_start_date]
, [customFieldList-custrecord_scl_ib_ams_end_date]
, [customFieldList-custrecord_scl_ib_ams_term]
, [customFieldList-custrecord_scl_ib_parent_install_base]
, [customFieldList-custrecord_scl_ib_ship_from]
, [customFieldList-custrecord_scl_ib_status]
, [customFieldList-custrecord_scl_ib_date_created]
, [customFieldList-custrecord_scl_sc_start_date]
, [customFieldList-custrecord_scl_sc_end_date]
, [customFieldList-custrecord_scl_sc_type]
, [customFieldList-custrecord_scl_sc_term]
, [customFieldList-custrecord_scl_sc_origin_transaction]
, [customFieldList-custrecord_scl_sc_origin_trans_line]
, [customFieldList-custrecord_legacy_contract_line]
, [customFieldList-custrecord_legacy_order_number]
, [customFieldList-custrecord_legacy_order_line]
, [customFieldList-custrecord_scl_manual_override]
, [customFieldList-custrecord_create_sales_out]
, [customFieldList-custrecord_clean_up_contracts]
, [customFieldList-custrecord_parent_item]
, [customFieldList-custrecord_sc_scl_parent_des]
, [isInactive]
, [created]
, [lastModified]
FROM [fdw_raw].[fdw_raw].ns_custom_servicecontractline 
GO






/**************************************************************************************************************************
**                                          END OF SCRIPT LS_FDW_SOURCE_VIEW                                             **
***************************************************************************************************************************/
